<div class="w-md-80 text-center mx-md-auto mb-9">
    <h2><?= $settings['title'] ?></h2>
    <p><?= $settings['content'] ?></p>
</div>