<?php if($settings['select_layout']=='desktop_layout'): ?>
<div class="row">
    <div class="col-md-12">
        <!-- Nav tab -->
        <ul class="nav nav-lb-tab mb-6">
           <li class="nav-item" role="presentation">
                <a class="nav-link active" data-filter="*">All</a>
            </li>
            <?php $category = get_categories(['taxonomy'=>'course_category','order'=>'DESC','include'=>array(124,4,3,5,71)]); ?>
            <?php foreach($category as $index => $cat):
            if($index<=6):
            ?>
            <li class="nav-item" role="presentation">
                <a class="nav-link" data-filter=".<?php echo $cat->slug; ?>"><?php echo $cat->name; ?>				</a>
            </li>
            <?php endif; 
        endforeach;  ?>

        </ul>
        <!-- Tab content -->
        <div class="tab-content">

           
            <div class="slider-single row">
                <?php
               
                    $args=array(
                        'post_status' => 'publish', 
                        'post_type' => 'lp_course',
						'orderby'=> 'post_date',
                        'order' =>'DESC',
                        'posts_per_page'   => 16,
                        'taxonomy'=>'course_category',
                    );
                    $course=new WP_Query($args);
                
                    if($course->have_posts()):
                        while($course->have_posts()):
                            $course->the_post();
                            $slugs = [];
                            $course_cat = wp_get_post_terms( get_the_ID(), 'course_category' );
                            foreach ($course_cat as $cat){
                                $slugs[] = $cat->slug;
                            }
                        
                ?>
                <div class="col-lg-3 course_list <?php echo  implode(' ', $slugs)?>"
                    data-category=".<?php echo  implode(' ', $slugs)?>">
                    <!-- Card -->
                    <div class="card card-hover mb-3">
                        <a href="<?= the_permalink(); ?>" class="card-img-top">
                            <!-- echo $course->get_image( 'course_thumbnail' );     -->
                            <img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>"
                                class="rounded-top-md card-img-top" title="<?php the_title(); ?>">
                        </a>
                        <!-- Card Body -->
                        <div class="card-body">
                            <h4 class="mb-2 text-truncate-line-2 "><a href="<?= the_permalink(); ?>"
                                    class="text-inherit"><?php the_title(); ?></a></h4>
                            <!-- List -->
                            <ul class="mb-3 list-inline">
                                <!-- <li class="list-inline-item"><i class="far fa-clock me-1"></i>3h 56m</li> -->
                                <li class="list-inline-item">
                                    <svg class="me-1 mt-n1" width="16" height="16" viewBox="0 0 16 16" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <rect x="3" y="8" width="2" height="6" rx="1" fill="#754FFE" />
                                        <rect x="7" y="5" width="2" height="9" rx="1" fill="#DBD8E9" />
                                        <rect x="11" y="2" width="2" height="12" rx="1" fill="#DBD8E9" />
                                    </svg>
                                    <?php $level = learn_press_get_post_level( get_the_ID() ); ?>
                                    <?php echo esc_html( $level ); ?>
                                </li>
                            </ul>
                            <div class="lh-1">
                                <span>
                                    <i class="mdi mdi-star text-warning me-n1"></i>
                                    <i class="mdi mdi-star text-warning me-n1"></i>
                                    <i class="mdi mdi-star text-warning me-n1"></i>
                                    <i class="mdi mdi-star text-warning me-n1"></i>
                                    <i class="mdi mdi-star text-warning"></i>
                                </span>
                                <span class="text-warning">4.5</span>
                                <span class="fs-6 text-muted">(7,700)</span>
                            </div>
                        </div>
                        <!-- Card Footer -->
                        <!-- <div class="card-footer">
                            <div class="row align-items-center g-0">
                                <div class="col-auto">
                                    <img src="../../assets/images/avatar/avatar-1.jpg" class="rounded-circle avatar-xs"
                                        alt="">
                                </div>
                                <div class="col ms-2">
                                    <span>Morris Mccoy</span>
                                </div>
                                <div class="col-auto">
                                    <a href="#" class="text-muted bookmark">
                                        <i class="fe fe-bookmark  "></i>
                                    </a>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
                <?php
                
                    wp_reset_query();
                        endwhile;
                    endif;
                ?>
            </div>
        </div>
	</div>
</div>
	<?php else: ?>
<div class="row">
    <div class="col-md-12">
		<div class="courses-boxes">
		<?php $category = get_categories(['taxonomy'=>'course_category','order'=>'DESC','include'=>array(124,4,3,5,71)]); 
// 				var_dump($category);
			?>
            <?php foreach($category as $index => $cat):
            if($index<=6): 
			$url = get_term_link($cat);
			?>
			<div class="courses-box"> 
					<a href="<?= $url; ?>" class="courses-b matchheight">
						<div class="courses-bicon">
							 <?= $cat->description; ?>
						</div>
						<h3><?= $cat->name; ?></h3>
					</a>
			</div>
		
				<?php endif; 
        endforeach;  ?>

			
		</div>
   </div>
</div>
<?php endif; ?>
 