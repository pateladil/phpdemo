<?php
class Testimonial_Elementor extends \Elementor\Widget_Base {


public function get_name() {
    return 'testimonial';
}
public function get_title() {
    return __( 'Testimonial', 'iiht' );
}
public function get_icon() {
    return 'fas fa-comments-alt';
}
public function get_categories() {
   
    return [ 'iiht_cat'];
}
protected function _register_controls() {

    $this->start_controls_section(
        'testimonial_section',
        [
            'label' => __( 'Testimonial', 'iiht' ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );
    $this->add_control(
			'select_layout', [
				'label' => __( 'Select Title', 'iiht' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => __( 'testimonial_list' , 'iiht' ),
				'options' => [
					'testimonial'  => __( 'Testimonial', 'iiht' ),
					'testimonial_list'  => __( 'Testimonial List', 'iiht' )
				],
			]
		);
    $testimonial = new \Elementor\Repeater();
    $testimonial->add_control(
        'image',
        [
            'label' => __( 'Choose Image', 'iiht' ),
            'type' => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ]
    );
    $testimonial->add_group_control(
        \Elementor\Group_Control_Image_Size::get_type(),
        [
            'name' => 'image',
            'default' => 'thumbnail',
            'separator' => 'none',
        ]
    );
    $testimonial->add_control(
        'name', [
            'label' => __( 'Name', 'iiht' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'label_block' => true,
        ]
    );
    $testimonial->add_control(
        'position', [
            'label' => __( 'Title', 'iiht' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'label_block' => true,
        ]
    );
    $testimonial->add_control(
        'content', [
            'label' => __( 'Content', 'iiht' ),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'label_block' => true,
        ]
    );
    $this->add_control(
        'testimonial_list', [
            'label' => __( 'Testimonial List' , 'iiht' ),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $testimonial->get_controls(),
        ]
            
    );
    
    $this->end_controls_section();
}
protected function render() {
       
    $settings = $this->get_settings_for_display(); 
        include 'templates/testimonial-part.php';
}

}