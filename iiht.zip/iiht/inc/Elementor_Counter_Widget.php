<?php

class Elementor_Counter_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'counter';
    }

    public function get_title() {
        return __( 'Counter', 'iiht' );
    }
    public function get_icon() {
        return 'eicon-counter';
    }
    public function get_categories() {
        return [ 'iiht_cat'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'iiht' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
       
//         $this->add_control(
// 			'select_layout',
// 			[
// 				'label' => __( 'Select Layout', 'iiht' ),
// 				'type' => \Elementor\Controls_Manager::SELECT,
// 				'default' => 'desktop_layout',
// 				'options' => [
// 					'desktop_layout'  => __( 'Desktop Layout', 'iiht' ),
// 					'mobile_layout' => __( 'Mobile Layout', 'iiht' ),
					
// 			],
// 			]
// 		);
 $counter = new \Elementor\Repeater();
    $counter->add_control(
        'image',
        [
            'label' => __( 'Choose Image', 'iiht' ),
            'type' => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ]
    );
  
    $counter->add_control(
        'icon_class', [
            'label' => __( 'Icon Class', 'iiht' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'label_block' => true,
        ]
    );
    $counter->add_control(
        'title', [
            'label' => __( 'Title', 'iiht' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'label_block' => true,
        ]
    );
    $counter->add_control(
        'value', [
            'label' => __( 'Value', 'iiht' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'label_block' => true,
        ]
    );
    $this->add_control(
        'counter_list', [
            'label' => __( 'Counter List' , 'iiht' ),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $counter->get_controls(),
        ]
            
    );
        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        include 'templates/counter.php';
    }   
}

                    
                            
                        
                    