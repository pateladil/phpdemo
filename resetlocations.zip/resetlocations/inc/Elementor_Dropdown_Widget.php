<?php

class Elementor_Dropdown_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'dropdown';
    }

    public function get_title() {
        return __( 'Dropdown', 'resetlocations' );
    }
    public function get_icon() {
        return 'fa fa-eyes';
    }
    public function get_categories() {
        return [ 'resetlocations_cat'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'resetlocations' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
       
        $drodown_list = new \Elementor\Repeater();
        $drodown_list->add_control(
            'dropdown_label', [
                'label' => __( 'Dropdown Label', 'resetlocations' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'drodown_list', [
                'label' => __( 'Dropdown Field' , 'resetlocations' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $drodown_list->get_controls(),
            ]
                
        );
        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        include 'templates/dropdown.php';
    }   

    
}

                    
                            
                        
                    