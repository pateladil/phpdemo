<?php
if($settings['select_layout']=='testimonial_list'):
?>
<div class="row mb-8">
    <!-- col -->
    <div class="col-md-12">
        <div class="position-relative">
            <!-- controls -->
            <ul class="controls-testimonial controls " id="sliderTestimonialControls">
                <li class="prev me-2 ms-0">
                    <i class="fe fe-chevron-left"></i>
                </li>
                <li class="next ms-2">
                    <i class="fe fe-chevron-right"></i>
                </li>
            </ul>
            <!-- slider -->
            <div class="sliderTestimonial">
            <?php foreach($settings['testimonial_list'] as $index => $testi): 
            ?>
                <div class="item">
                        <!-- card -->
                        <div class="card border shadow-none">
                            <!-- card body -->
                            <div class="card-body p-5">
                                <div class="mb-2">
                                    <span class="fs-4">
                                        <i class="mdi mdi-star text-warning me-n1"></i>
                                        <i class="mdi mdi-star text-warning me-n1"></i>
                                        <i class="mdi mdi-star text-warning me-n1"></i>
                                        <i class="mdi mdi-star text-warning me-n1"></i>
                                        <i class="mdi mdi-star text-warning"></i>
                                    </span>
                                </div>
                                <!-- para -->
                                <p class="lead text-dark font-italic fw-medium mb-0 card-description">
                                    <?= $testi['content']; ?>
                                </p>
                            </div>
                            <!-- card footer -->
                            <div class="card-footer px-5 py-4">
                                <div class="d-flex align-items-center">
                                    <!-- <img src="" alt=""
                                        class="avatar avatar-md rounded-circle"> -->
                                    <div class="ms-3">
                                        <h4 class="mb-0"><?= $testi['name']; ?></h4>
                                        <!-- <p class="mb-0 small"></p> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
                <?php endforeach; ?>
                </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="row">
     <?php foreach($settings['testimonial_list'] as $index => $testi): ?>
        <div class="col-md-6 col-12 mb-4 mb-lg-0">
            <!-- Card -->
          <div class="card shadow-lg">
              <!-- Card body -->
            <div class="card-body p-4 p-md-8 text-center">
              <i class="mdi mdi-48px mdi-format-quote-open text-light-primary lh-1"></i>
              <p class="lead text-dark mt-3"><?= $testi['content'] ?></p>
            </div>
              <!-- Card Footer -->
            <div class="card-footer bg-primary text-center border-top-0">
              <div class="mt-n8"><img src="<?= $testi['image']['url']; ?>" alt=""
                  class="rounded-circle border-primary avatar-xl border border-4"></div>
              <div class="mt-2 text-white">
                <h3 class="text-white mb-0"><?= $testi['name'] ?></h3>
                <p class="text-white-50 mb-1"><?= $testi['position'] ?></p>
              </div>
            </div>
          </div>
        </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>