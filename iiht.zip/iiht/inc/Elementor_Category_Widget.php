<?php

class Elementor_Category_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'course_category';
    }

    public function get_title() {
        return __( 'Course Category', 'iiht' );
    }
    public function get_icon() {
        return 'fa fa-eye';
    }
    public function get_categories() {
        return [ 'iiht_cat'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'iiht' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
       
        $this->add_control(
			'select_layout',
			[
				'label' => __( 'Select Layout', 'iiht' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'desktop_layout',
				'options' => [
					'desktop_layout'  => __( 'Desktop Layout', 'iiht' ),
					'mobile_layout' => __( 'Mobile Layout', 'iiht' ),
					
			],
			]
		);
        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        include 'templates/course_cat.php';
    }   
}

                    
                            
                        
                    