<select name="" id="">
     <?php foreach($settings['drodown_list'] as $index => $drp): 
            ?>
        <option value=""><?= $drp['dropdown_label']; ?></option>
     <?php endforeach; ?>
</select>