<?php

class Elementor_Title_Content_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'title_content';
    }

    public function get_title() {
        return __( 'Title & Content', 'iiht' );
    }
    public function get_icon() {
        return 'fa fa-heading';
    }
    public function get_categories() {
        return [ 'iiht_cat'];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'iiht' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
       
        $this->add_control(
            'title', [
                'label' => __( 'Title', 'iiht' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Title' , 'iiht' ),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'content', [
                'label' => __( 'Content', 'iiht' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __( 'Content' , 'iiht' ),
                'show_label' => false,
            ]
        );
        
        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        include 'templates/title_content.php';
    }   

    
}

                    
                            
                        
                    