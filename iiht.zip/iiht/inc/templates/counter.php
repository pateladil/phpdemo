<div class="container">
    <div class="row">
     <?php foreach($settings['counter_list'] as $index => $ct): 
            ?>
        <div class="col-md-3 col-sm-6">
            <div class="counter">
                <div class="counter-icon">
                <i class="<?= $ct['icon_class']; ?>"></i>
                </div>
                <h3><?= $ct['title']; ?></h3>
                <span class="counter-value"><?= $ct['value']; ?></span>
                </div>
        <div>
     <?php endforeach; ?>
    </div>
</div>